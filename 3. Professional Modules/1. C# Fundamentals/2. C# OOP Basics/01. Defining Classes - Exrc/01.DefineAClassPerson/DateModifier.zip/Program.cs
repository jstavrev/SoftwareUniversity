﻿using System;
using System.Linq;
using System.Reflection;

public class Program
{
    static void Main(string[] args)
    {
        string startDate = Console.ReadLine();
        string endDate = Console.ReadLine();

        DateModifier calc = new DateModifier();
        int dayDifference = calc.DayDifferenceCalculator(startDate, endDate);
        Console.WriteLine(dayDifference);
    }
}

